#pragma once

#include <cstdint>
#include <memory>
#include <string>
#include <string_view>

std::string blake3_hash(std::string_view data);

// Content-addressed store: LMDB index (32-byte BLAKE3 key -> offset/length)
// plus an append-only packfile read through a shared mmap.
//
// Concurrency: reads are safe from any thread/process. Writes take an
// exclusive flock on the packfile for the duration of a batch; batches are
// committed by sync() or automatically every kAutoSyncBytes. The index is
// committed only after the pack data is durable, so a crash can lose the
// tail of a batch but never yields an index entry pointing at bad data.
class PackCas {
public:
  static std::unique_ptr<PackCas> open(const std::string &dir);
  ~PackCas();

  PackCas(const PackCas &) = delete;
  PackCas &operator=(const PackCas &) = delete;

  std::string put(std::string_view data);
  bool get(std::string_view hash, std::string &out);
  // zero-copy; view valid until close
  bool get_view(std::string_view hash, std::string_view &out);
  bool has(std::string_view hash);
  void sync();

private:
  struct Impl;
  explicit PackCas(std::unique_ptr<Impl> impl);
  std::unique_ptr<Impl> impl_;
};
