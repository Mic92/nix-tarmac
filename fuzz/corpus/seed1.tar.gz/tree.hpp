#pragma once

#include "pack_cas.hpp"

#include <functional>
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

struct archive;

std::string to_hex(std::string_view raw);
std::string from_hex(std::string_view hex);

// 'r' regular, 'x' executable, 's' symlink (id = target blob), 'd' directory
struct TreeEntry {
  std::string name;
  char type;
  std::string id;
};

class TreeStore {
public:
  explicit TreeStore(std::unique_ptr<PackCas> cas) : cas_(std::move(cas)) {}

  std::string putBlob(std::string_view data) { return cas_->put(data); }
  std::string putTree(const std::vector<TreeEntry> &entries);
  std::vector<TreeEntry> readTree(const std::string &id);
  std::string readBlob(const std::string &id);
  bool readBlobView(const std::string &id, std::string_view &out) {
    return cas_->get_view(id, out);
  }
  bool hasTree(const std::string &id);
  void sync() { cas_->sync(); }

private:
  std::unique_ptr<PackCas> cas_;
};

struct IngestResult {
  std::string root;
  uint64_t files = 0;
};

// consumes and frees the archive; caller opened it (file, memory, stream)
IngestResult ingest_archive(TreeStore &store, struct archive *a);
IngestResult ingest_tarball_file(TreeStore &store, const std::string &path);

struct TreeWalker {
  TreeStore &store;
  std::unordered_map<std::string, std::vector<TreeEntry>> cache;

  const std::vector<TreeEntry> &tree(const std::string &id);
  bool lookup(const std::string &root, std::string_view path, TreeEntry &out);
};

void nar_dump(TreeStore &store, const std::string &root,
              const std::function<void(std::string_view)> &sink);

// returns raw 32-byte sha256 of the NAR
std::string nar_sha256(TreeStore &store, const std::string &root,
                       uint64_t &nar_size);
